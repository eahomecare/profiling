export interface ServiceObject {
  serviceTitle: string;
  serviceDescription: string;
}
